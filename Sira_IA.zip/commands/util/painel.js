const { ApplicationCommandType } = require("discord.js");
const { botconfig } = require("../../Functions/painel");

module.exports = {
  name: "panel",
  description: "[Sira IA] Meu painel de inteligência!",
  type: ApplicationCommandType.ChatInput,
  run: async (client, interaction) => {
    try {
      await botconfig(interaction, client);
    } catch (error) {
      console.error("Erro ao executar o comando /panel:", error);
      interaction.reply({ content: "❌ | Ocorreu um erro ao executar este comando.", ephemeral: true });
    }
  },
};