const { ApplicationCommandType } = require("discord.js");


module.exports = {
    name:"ping", 
    description:"[Sira IA] Tenho meu ping em mão!", 
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => { 
        interaction.reply({ 
            content:`Olá ${interaction.user}, estou verificando meu ping `, ephemeral: true
        });

        setTimeout(() => { 
            interaction.editReply({
                content:`${interaction.user}, Meu ping está desse jeito: ${client.ws.ping}`
            });
        }, 1500); 

    }
}