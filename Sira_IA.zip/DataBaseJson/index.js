const {
    JsonDatabase,
  } = require("wio.db");
  
  const config = new JsonDatabase({
    databasePath: "./DataBaseJson/config.json"
  });
  
  
  module.exports = {
    config
  }