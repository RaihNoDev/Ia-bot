const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { config } = require("../DataBaseJson");

async function apikey(interaction, client) {
  try {
    const apiKey = config?.get("apiKey");

    const embed = new EmbedBuilder()
      .setColor("#2C2F33") // Substituí NotQuiteBlack por hexadecimal válido
      .setTitle("`Configurar Api Key`")
      .setDescription(
        "Configure a API key\n- API que será utilizada para o bot conseguir responder"
      )
      .addFields({
        name: "ApiKey Atual",
        value: apiKey ? `**\`${apiKey}\`**` : "`Não definido`",
      })
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({
        text: "Configurações",
        iconURL:
          "https://cdn.discordapp.com/attachments/1316586098075635794/1327252535874027560/Vip.png-1.webp",
      });

    const row24 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("configurarapikey")
        .setLabel("Configurar ApiKey")
        .setEmoji("🔑")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setURL("https://aistudio.google.com/app/apikey")
        .setLabel("Pegar API")
        .setEmoji("🌐")
        .setStyle(ButtonStyle.Link),
      new ButtonBuilder()
        .setCustomId("configurar")
        .setLabel("Voltar")
        .setEmoji("↩️")
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({ embeds: [embed], components: [row24] });
  } catch (error) {
    console.error("Erro ao executar apikey:", error);
    await interaction.reply({
      content: "❌ Ocorreu um erro ao executar a configuração da API Key.",
      ephemeral: true,
    });
  }
}

module.exports = {
  apikey,
};