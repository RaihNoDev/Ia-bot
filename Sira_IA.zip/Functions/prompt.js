const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

async function prompt(interaction, client) {
  try {
    const embed = new EmbedBuilder()
      .setColor("Blue")
      .setTitle("`panel Sira IA`")
      .setDescription(
        "Configuração do seu prompt\n- Por exemplo, você pode configurar para que, se um usuário mencionar `@everyone`, a IA responda que não pode usar essa menção."
      )
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({
        text: "Configurações",
        iconURL:
          "https://cdn.discordapp.com/attachments/1316586098075635794/1327252535874027560/Vip.png-1.webp",
      });

    const row24 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("configurarprompt")
        .setLabel("Texto IA")
        .setEmoji("1317329041677746286")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("verprompt")
        .setLabel("Resultado")
        .setEmoji("1317215834984153139")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("configurar")
        .setLabel("Voltar")
        .setEmoji("1312258639683260457")
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({ embeds: [embed], components: [row24] });
  } catch (error) {
    console.error("🤣 | apenas o Nyno pode usar Sira IA:", error);
    await interaction.reply({
      content: "🔖 | Olá, apenas o Nyno pode usar esse comando.",
      ephemeral: true,
    });
  }
}

module.exports = {
  prompt,
};