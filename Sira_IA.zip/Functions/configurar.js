const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, ButtonStyle } = require("discord.js");
const { config } = require("../DataBaseJson");

async function configurar(interaction, client) {
  try {
    const embed = new EmbedBuilder()
      .setColor("#2C2F33") // Substituído NotQuiteBlack por um hexadecimal válido
      .setTitle("`Configuração de inteligência artificial`")
      .setDescription(
        "Inteligência Artificial Germine\n- Configure clicando no menu abaixo"
      )
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({
        text: "Gudys Community",
        iconURL: "https://cdn.discordapp.com/icons/1212226623546593310/8f3c82b60be69c315fac04ceb89e1e6b.png?size=2048",
      });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId("configgermine")
      .setPlaceholder("Germine Config")
      .addOptions([
        {
          label: "Sira Canal",
          description: "Configura canal sira",
          emoji: "📢", // Alterado para emoji padrão
          value: "canal",
        },
        {
          label: "Sira API",
          description: "configura sua api key",
          emoji: "🔑",
          value: "apikey",
        },
        {
          label: "Sira Config",
          description: "Configura sua sita ia",
          emoji: "💡",
          value: "prompt",
        },
      ]);

    const voltar = new ButtonBuilder()
      .setCustomId("voltar01")
      .setLabel("Voltar")
      .setEmoji("↩️")
      .setStyle(ButtonStyle.Secondary);

    const row4 = new ActionRowBuilder().addComponents(selectMenu);

    const row24 = new ActionRowBuilder().addComponents(voltar);

    // Responder ou atualizar interação
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        embeds: [embed],
        components: [row4, row24],
        ephemeral: true,
      });
    } else {
      await interaction.update({
        embeds: [embed],
        components: [row4, row24],
      });
    }
  } catch (error) {
    console.error("Erro na função configurar:", error);
    await interaction.reply({
      content: "❌ Ocorreu um erro ao executar a configuração.",
      ephemeral: true,
    });
  }
}

module.exports = {
  configurar,
};