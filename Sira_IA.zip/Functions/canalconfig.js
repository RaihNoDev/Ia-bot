const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { config } = require("../DataBaseJson");

async function canalconfig(interaction, client) {
  try {
    const canalAtual = config?.get("canalrespostas");

    const embed = new EmbedBuilder()
      .setColor("#2C2F33") // Substituí NotQuiteBlack por hexadecimal válido
      .setTitle("`Configurar canal`")
      .setDescription(
        "Configure o canal de respostas\n- Canal que a inteligência artificial irá responder às perguntas"
      )
      .addFields({
        name: "Canal Atual",
        value: canalAtual ? `<#${canalAtual}>` : "`Não definido`",
      })
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({
        text: "Configurações",
        iconURL: "https://cdn.discordapp.com/icons/1212226623546593310/8f3c82b60be69c315fac04ceb89e1e6b.png?size=2048",
      });

    const row24 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("configurarcanal")
        .setLabel("Configurar Canal")
        .setEmoji("🛠️") // Alterado para emoji padrão
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("configurar")
        .setLabel("Voltar")
        .setEmoji("↩️") // Alterado para emoji padrão
        .setStyle(ButtonStyle.Secondary)
    );

    // Atualizar a interação
    await interaction.update({ embeds: [embed], components: [row24] });
  } catch (error) {
    console.error("Erro ao executar canalconfig:", error);
    await interaction.reply({
      content: "❌ Ocorreu um erro ao executar a configuração do canal.",
      ephemeral: true,
    });
  }
}

module.exports = {
  canalconfig,
};