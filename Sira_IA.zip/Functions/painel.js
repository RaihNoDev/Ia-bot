const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { config } = require("../DataBaseJson");

async function botconfig(interaction, client) {
  try {
    const status = config?.get("status") || false;

    const embed4 = new EmbedBuilder()
      .setAuthor({ name: `${interaction.guild.name}`, iconURL: `${client.user.displayAvatarURL({ dynamic: true })}` })
      .setDescription(`- Ola, Sou a Sita IA Uma inteligência artificial\n- Esse e meu painel de controle\n- Nele você pode configurar minha permissão\n- Configura com atenção sem erros por gentileza.`)
      .setColor("#15c1ff")
      .addFields({ name: `Status`, value: `${status ? '\`🟢 Sira Online\`' : '\`🔴 Sira Offline\`'}`, inline: true })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("onoff")
        .setLabel(status ? "Sira on" : "Sira off")
        .setEmoji(status ? "1318047369023193118" : "1318046568846196858")
        .setStyle(status ? 3 : 4),
      new ButtonBuilder()
        .setCustomId("configurar")
        .setLabel("Painel IA")
        .setEmoji("1324691453791834132")
        .setStyle(2)
    );

    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ embeds: [embed4], components: [row], ephemeral: true });
    } else {
      await interaction.editReply({ embeds: [embed4], components: [row] });
    }
  } catch (error) {
    console.error("🤣 | Apenas o Nyno pode usar o /panel:", error);
    await interaction.reply({
      content: "🔖 | Olá, apenas o Nyno pode usar esse comando.",
      ephemeral: true,
    });
  }
}

module.exports = {
  botconfig,
};