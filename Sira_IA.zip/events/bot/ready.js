const {} = require("discord.js");
const axios = require("axios");

module.exports = {
    name: "ready",
    run: async(client, interaction) => {
        console.clear();
        console.log("\n");
        console.log('\x1b[31m%s\x1b[0m', "                                                                                                                           ");
        console.log('\x1b[31m%s\x1b[0m', "                                                                                                                         ");
        console.log('\x1b[31m%s\x1b[0m', "                          ██████╗ █████╗ ██╗ ██████╗ ██╗  ██╗                                   ");
        console.log('\x1b[31m%s\x1b[0m', "                         ██╔════╝██╔══██╗██║██╔═══██╗╚██╗██╔╝                                   ");
        console.log('\x1b[31m%s\x1b[0m', "                         ██║     ███████║██║██║   ██║ ╚███╔╝                                    ");
        console.log('\x1b[31m%s\x1b[0m', "                         ██║     ██╔══██║██║██║   ██║ ██╔██╗                                    ");
        console.log('\x1b[31m%s\x1b[0m', "                         ╚██████╗██║  ██║██║╚██████╔╝██╔╝ ██╗                                   ");
        console.log('\x1b[31m%s\x1b[0m', "                          ╚═════╝╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═╝  ╚═╝                                   ");
        console.log('\x1b[31m%s\x1b[0m', "                                                                             ");
        console.log('\x1b[31m%s\x1b[0m', "                                                                                                                      ");
        console.log('\x1b[31m%s\x1b[0m', "                                                                                          ");
        console.log('\x1b[31m%s\x1b[0m', "                                                                                        ");
        console.log('\x1b[31m%s\x1b[0m', '                              > Desenvolvido por @Nyno | Programer <');
        console.log('\x1b[31m%s\x1b[0m', `                               > Estou online em ${client.user.username} <`);
        console.log('\x1b[31m%s\x1b[0m', `                                > Estou em ${client.guilds.cache.size}, Servidores XD <`);
        console.log('\x1b[31m%s\x1b[0m', `                                 > Tenho ${client.users.cache.size} Amigos :D <`);
        console.log('\x1b[31m%s\x1b[0m', `                                   > Source key <`);
        console.log('\x1b[31m%s\x1b[0m', `                                    > 1.0.0 <`);

        const { token } = require("../../config.json");

        const description = `**Bot Feito Por Nyno**`;
        await axios.patch(`https://discord.com/api/v10/applications/${client.user.id}`, {
            description: description
        }, {
            headers: {
                "Authorization": `Bot ${token}`,
                "Content-Type": 'application/json',
            }
        });
    }
}
