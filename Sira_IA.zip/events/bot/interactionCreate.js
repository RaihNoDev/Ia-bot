const { Events } = require("discord.js");
const { config } = require("../../DataBaseJson/index");
const { GoogleGenerativeAI } = require('@google/generative-ai');
const fs = require('fs');
const path = require('path');

const genAI = new GoogleGenerativeAI(String(config.get('apiKey')));

module.exports = {
    name: Events.MessageCreate,
    run: async (mensagem) => {
        if (mensagem.author.bot) return;

        const canalRespostas = config.get("canalrespostas");
        const status = config.get("status");

        if (!config.get('apiKey') || !canalRespostas || !status) return;

        if (mensagem.channel.id === canalRespostas) {
            const pergunta = mensagem.content;

            const mensagemResposta = await mensagem.reply('[Sira IA] estou procurando sua resposta');

            try {
                const modelo = genAI.getGenerativeModel({ model: 'gemini-1.5-pro' });

                const chat = modelo.startChat({
                    history: [
                        {
                            role: 'user',
                            parts: [{ text: String(config.get("prompt")) }],
                        },
                    ],
                });

                const resultado = await chat.sendMessage(pergunta);
                const resposta = await resultado.response;
                const texto = resposta.text();

                if (texto.length > 200) {
                    const caminhoArquivo = path.join(__dirname, 'Sua pergunta está logo abaixo.');
                    fs.writeFileSync(caminhoArquivo, texto);

                    await mensagemResposta.edit({
                        content: 'Sua Resposta está logo em baixo:',
                        files: [caminhoArquivo],
                    });
                    fs.unlinkSync(caminhoArquivo)
                } else {
                    await mensagemResposta.edit({ content: `${String(texto)}\n-# **Criando:** Nyno | Programer` });
                }
            } catch (erro) {
                await mensagemResposta.edit({ content: 'Nao posso responder esse tipo de pergunta..' });
                console.log(erro)
            }
        }
    },
};
