const { ModalBuilder, TextInputBuilder, ButtonStyle, ButtonBuilder, TextInputStyle, ActionRowBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder } = require("discord.js");
const { config } = require("../../DataBaseJson/index.js");
const { botconfig } = require("../../Functions/painel.js")
const { configurar } = require("../../Functions/configurar.js")

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        const { customId } = interaction;
        if (!customId) return;

        if (customId === "onoff") {
            const atualstatus = config.get("status") || false
            const resultado = !atualstatus
            config.set("status", resultado)
            botconfig(interaction, client)
        }

        if (customId === "voltar01") {
            botconfig(interaction, client)
        }

        if (customId === "configurar") {
            configurar(interaction, client)
        }

    }
};