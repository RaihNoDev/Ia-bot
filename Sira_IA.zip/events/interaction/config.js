const { ApplicationCommandType, EmbedBuilder, ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelSelectMenuBuilder, ChannelType, ButtonBuilder } = require("discord.js");
const { config } = require("../../DataBaseJson");
const { canalconfig } = require("../../Functions/canalconfig");
const { apikey } = require("../../Functions/apikey");
const { prompt } = require("../../Functions/prompt");

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        const { customId } = interaction;
        if (!customId) return;

        if (customId === 'configgermine' && interaction.values.includes('canal')) {
            canalconfig(interaction, client);
        }

        if (customId === 'configgermine' && interaction.values.includes('apikey')) {
            apikey(interaction, client);
        }

        if (customId === 'configgermine' && interaction.values.includes('prompt')) {
            prompt(interaction, client);
        }

        if (customId === 'configurarcanal') {
            const selectmenu = new ChannelSelectMenuBuilder()
                .setCustomId('selecionarcanal')
                .setPlaceholder('Selecione um canal')
                .setMinValues(1)
                .setMaxValues(1)
                .addChannelTypes(0);

            const row4 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                .setCustomId("voltar02")
                .setLabel("Voltar")
                .setEmoji("1251585346387443742")
                .setStyle(2)
            );  

            const row = new ActionRowBuilder().addComponents(selectmenu);

            await interaction.update({
                components: [row, row4],
                ephemeral: true
            });
        }

        if (customId === 'selecionarcanal') {
           const canal = interaction.values[0];
           config.set("canalrespostas", canal);
           canalconfig(interaction, client);
        }

        if (customId === 'voltar02') {
            canalconfig(interaction, client);
        }

        if (customId === 'configurarapikey') {
            const modal = new ModalBuilder()
                .setCustomId('apikeyModal')
                .setTitle('Configurar API Key');
        
            const apiKeyInput = new TextInputBuilder()
                .setCustomId('apiKeyInput')
                .setLabel('Digite sua API Key')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Caiox')
                .setRequired(true);
        
            const actionRow = new ActionRowBuilder().addComponents(apiKeyInput);
        
            modal.addComponents(actionRow);
        
            await interaction.showModal(modal);
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'apikeyModal') {
                const apiKey = interaction.fields.getTextInputValue('apiKeyInput');
                config.set("apiKey", apiKey);

                apikey(interaction, client);
            }
        }

        if (customId === 'configurarprompt') {
            const modal = new ModalBuilder()
                .setCustomId('promptmodal2024')
                .setTitle('Configurar Prompt IA');

            const input2024 = new TextInputBuilder()
                .setCustomId('promptinput')
                .setLabel('Digite Seu Prompt Aqui')
                .setStyle(TextInputStyle.Paragraph)
                .setMaxLength(1000)
                .setValue(config.get("prompt") || "Ola Germine")
                .setRequired(true);

            const actionRow = new ActionRowBuilder().addComponents(input2024);

            modal.addComponents(actionRow);

            await interaction.showModal(modal);
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'promptmodal2024') {
                const apiKey = interaction.fields.getTextInputValue('promptinput');
                config.set("prompt", apiKey);

                prompt(interaction, client);
            }
        }

        if (customId === 'verprompt') {
            const prompt = config.get("prompt") || "Não Definido";

            await interaction.reply({ content: prompt, ephemeral: true });
        }
    }
};