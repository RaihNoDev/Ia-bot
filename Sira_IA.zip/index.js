const { Client, GatewayIntentBits, Collection, Partials, EmbedBuilder } = require("discord.js");
const axios = require("axios");
console.clear();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping
  ],
  partials: [
    Partials.Message,
    Partials.Channel
  ]
});

module.exports = client;
client.slashCommands = new Collection();
const { token } = require("./config.json");
client.login(token);

const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);

process.on('unhandledRejection', (reason, promise) => {
});

process.on('uncaughtException', (error, origin) => {
});

client.on('ready', async () => {

  const description = `**<:emoji_178:1327396071260819497> Sira IA inteligência artificial\n\n<:emoji_32:1317972552517419122> Servidor da Sira IA\nhttps://discord.gg/gudyscommunity**`;

  try {
    await axios.patch(`https://discord.com/api/v10/applications/${client.user.id}`, {
      description: description
    }, {
      headers: {
        "Authorization": `Bot ${token}`,
        "Content-Type": 'application/json',
      }
    });
  } catch (error) {
  }
});


client.on('messageCreate', (message) => {
  if (message.mentions.has(client.user)) {
    const embed = new EmbedBuilder()
      .setAuthor({ 
        name: `${message.author.username}`, 
        iconURL: `${message.author.displayAvatarURL({ dynamic: true })}` 
      })
      .setDescription(`<:emoji_178:1327396071260819497> Olá me chamou ${message.author}, Sou a Sira IA Uma inteligência artificial, ser quiser me perguntar alguma pergunta eu irei responder..\n\n<:emoji_32:1317972552517419122> Nosso servidor onde tem o bot para adicionar\nhttps://discord.gg/gudyscommunity`)
      .setColor("NotQuiteBlack")
      .setTimestamp();
    
    message.reply({ embeds: [embed] }).then(sentMessage => {
      setTimeout(() => {
        sentMessage.delete().catch(err => console.error('Nyx'));
      }, 10000);
    }).catch(err => console.error('Nyx'));
  }
});


